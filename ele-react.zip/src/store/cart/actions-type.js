export const ADD_TO_CART = 'ADD_TO_CART';
export const PRODUCT_COUNT = 'PRODUCT_COUNT';
export const DELETE_FROM_CART = 'DELETE_FROM_CART';
export const CELAR_ALL_CART = 'CELAR_ALL_CART';
