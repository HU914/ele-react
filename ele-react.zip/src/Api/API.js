import Tip from '../../plug-ins/alertModul/modul';


/*Api public Function*/
export default class Api {

  /**
   * tip Api
  */

  
}
